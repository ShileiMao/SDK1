//
//  MySwiftLib.h
//  MySwiftLib
//
//  Created by Shilei Mao on 22/11/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for MySwiftLib.
FOUNDATION_EXPORT double MySwiftLibVersionNumber;

//! Project version string for MySwiftLib.
FOUNDATION_EXPORT const unsigned char MySwiftLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MySwiftLib/PublicHeader.h>


